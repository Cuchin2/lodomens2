<video class="top-0 z-[-10] left-0 hidden lg:block fixed" src="{{ asset('storage/image/video_fondo.mp4') }}" autoplay muted loop controls poster="{{ asset('storage/image/video.png') }}"></video>
