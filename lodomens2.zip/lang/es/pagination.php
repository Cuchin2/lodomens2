<?php

declare(strict_types=1);

return [
    'next'     => 'Siguiente',
    'previous' => 'Anterior',
];
