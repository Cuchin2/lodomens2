import './bootstrap';
import Scroll from '@alpine-collective/toolkit-scroll'
import sort from '@alpinejs/sort'
Alpine.plugin(Scroll)
Alpine.plugin(sort)
