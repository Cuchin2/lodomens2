<div {{ $attributes->merge(['class' => 'bg-white dark:bg-gris-80 overflow-hidden shadow-xl sm:rounded-lg p-4 dark:text-gris-30']) }}>
    {{ $slot }}
</div>
