
<input id="inline-checkbox" type="checkbox" 
{{ $attributes->merge(['class' => 'w-4 h-4 text-corp-50 bg-gray-100 border-gray-300 rounded focus:ring-corp-50 dark:focus:ring-corp-70 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gris-90 dark:border-gray-600 focus:ring-offset-0 cursor-pointer']) }} >