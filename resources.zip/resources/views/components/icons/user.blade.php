@props(['fill'=>'currentColor','grosor'=>'0'])

<svg version="1.1"  fill="{{$fill}}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20; display: inherit;" xml:space="preserve" {{ $attributes->merge(['class' => '']) }}>
    <g id="ico-user">
        <path stroke-width="{{$grosor}}" stroke="{{$fill}}"  d="M10,11c-2.9,0-5.3-2.4-5.3-5.3S7.1,0.4,10,0.4s5.3,2.4,5.3,5.3S12.9,11,10,11z M10,1.3c-2.4,0-4.3,1.9-4.3,4.3
            S7.6,10,10,10s4.3-1.9,4.3-4.3S12.4,1.3,10,1.3z"></path>
        <path stroke-width="{{$grosor}}" stroke="{{$fill}}"  d="M17.7,19.6H2.3c-0.8,0-1.4-0.6-1.4-1.4c0-0.1,0-1.6,1.2-3.2c0.7-0.9,1.6-1.6,2.8-2.1c1.4-0.6,3.2-0.9,5.2-0.9
            s3.8,0.3,5.2,0.9c1.2,0.5,2.1,1.2,2.8,2.1c1.2,1.6,1.2,3.1,1.2,3.2C19.2,19,18.5,19.6,17.7,19.6z M10,12.9c-3.4,0-5.8,0.9-7.2,2.7
            c-1,1.3-1,2.6-1,2.6c0,0.3,0.2,0.5,0.5,0.5h15.4c0.3,0,0.5-0.2,0.5-0.5c0,0,0-1.3-1-2.6C15.8,13.8,13.4,12.9,10,12.9z"></path>
    </g>
</svg>
