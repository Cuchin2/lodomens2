@props(['title'])
<div class="flex">
    <h1 class="dark:text-gris-20 font-normal leading-[25.20px] ml-10 text-[18px]" >{{$title}}</h1>
</div>
