@props(['fill'=>'currentColor','grosor'=>'0'])

<svg version="1.1"  fill="{{$fill}}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20; display: inherit;" xml:space="preserve" {{ $attributes->merge(['class' => '']) }}>
    <g id="ico-cross" >
        <path class="st1" stroke-width="{{$grosor}}" stroke="{{$fill}}" d="M10.7,9.9l7.4-7.5c0.2-0.2,0.2-0.5,0-0.7c-0.2-0.2-0.5-0.2-0.7,0L10,9.2L2.5,1.7C2.3,1.5,2,1.5,1.8,1.7
            c-0.2,0.2-0.2,0.5,0,0.7l7.4,7.5l-7.4,7.5c-0.2,0.2-0.2,0.5,0,0.7c0.1,0.1,0.2,0.1,0.4,0.1c0.1,0,0.3,0,0.4-0.1l7.4-7.5l7.4,7.5
            c0.1,0.1,0.2,0.1,0.4,0.1s0.3,0,0.4-0.1c0.2-0.2,0.2-0.5,0-0.7L10.7,9.9z"></path>
    </g>
</svg>

