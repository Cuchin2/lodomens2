<svg class="w-5 h-4 text-gris-30" viewBox="0 0 20 20" fill="none" stroke="currentColor">
    <path d="M7 7l3-3 3 3m0 6l-3 3-3-3" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round"></path>
</svg> 