<?php

namespace App\Livewire;

use Livewire\Component;

class StarShow extends Component
{
    public $star;
    public function render()
    {
        return view('livewire.star-show',);
    }
}
