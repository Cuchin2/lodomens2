@props(['height','width','fill'=>'currentColor','grosor'=>'0', 'm'=>'inherit'])

<svg version="1.1" height="{{$height}}" width="{{$width}}" fill="{{$fill}}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20; display: inherit; margin:{{$m}}" xml:space="preserve">
    <g id="ico-folder" >
        <g class="st1">
            <path stroke-width="{{$grosor}}" stroke="{{$fill}}" d="M2.5,18c-0.6,0-1.2-0.2-1.6-0.7c-0.4-0.4-0.7-1-0.7-1.6V3.5c0-1.2,1-2.2,2.2-2.2H7c0.5,0,0.9,0.2,1.2,0.5l1.6,1.6l8,0
                c1.2,0,2.1,1,2.1,2.1v10.2c0,1.2-1,2.2-2.2,2.2L2.5,18C2.5,18,2.5,18,2.5,18z M2.4,2.3c-0.6,0-1.2,0.5-1.2,1.2v12.3
                c0,0.3,0.1,0.7,0.4,0.9C1.9,16.9,2.2,17,2.5,17l15.2,0h0c0.6,0,1.2-0.5,1.2-1.2V5.6c0-0.6-0.5-1.1-1.1-1.1H9.9
                c-0.3,0-0.6-0.1-0.8-0.3L7.5,2.5C7.4,2.4,7.2,2.3,7,2.3H2.4z"></path>
        </g>
    </g>
</svg>
