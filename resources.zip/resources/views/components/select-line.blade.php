<select {{ $attributes }} class="dark:bg-gris-100 w-full focus:ring-gris-100 bg-inherit border-0 border-b-[1px] border-gris-70 focus:border-b-[1px] focus:border-gris-70 focus:placeholder-gris-70 placeholder-gris-30"
>
{{ $slot }}
</select>


