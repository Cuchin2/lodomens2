<div>
    {{-- If you look to others for fulfillment, you will never truly be fulfilled. --}}
    <x-star class="h-6 w-6" star="{{ $star }}"/>
</div>
