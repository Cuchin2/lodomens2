import './bootstrap';
import Scroll from '@alpine-collective/toolkit-scroll'
Alpine.plugin(Scroll)
