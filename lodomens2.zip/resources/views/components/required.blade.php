<div class="relative">
<span class="text-corp-30 ml-1 font-bold cursor-pointer text-[20px] absolute top-0" title="campo obligatorio">*</span>
</div>